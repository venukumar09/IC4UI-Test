import { FilterDataIngestionPipe } from './filter-data-ingestion.pipe';

describe('FilterDataIngestionPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterDataIngestionPipe();
    expect(pipe).toBeTruthy();
  });
});
