import { FilterDataByTypesPipe } from './filter-data-by-types.pipe';

describe('FilterDataByTypesPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterDataByTypesPipe();
    expect(pipe).toBeTruthy();
  });
});
