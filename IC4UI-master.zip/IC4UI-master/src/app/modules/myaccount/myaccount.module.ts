import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MyaccountRoutingModule } from './myaccount-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MyaccountRoutingModule
  ]
})
export class MyaccountModule { }
