import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-curate-services',
  templateUrl: './curate-services.component.html',
  styleUrls: ['./curate-services.component.scss']
})
export class CurateServicesComponent implements OnInit {

  constructor() { }

  service : any;

  ngOnInit() {
  }

}
