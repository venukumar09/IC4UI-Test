import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-curate',
  templateUrl: './curate.component.html',
  styleUrls: ['./curate.component.scss']
})
export class CurateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
