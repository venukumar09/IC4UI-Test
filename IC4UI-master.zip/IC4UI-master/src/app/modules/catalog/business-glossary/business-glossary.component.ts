import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-business-glossary',
  templateUrl: './business-glossary.component.html',
  styleUrls: ['./business-glossary.component.scss']
})
export class BusinessGlossaryComponent implements OnInit {

  isvisible:Boolean=true;
  
  constructor() { }

  ngOnInit() {
  }

  updateConnection(){
    
  }

}
