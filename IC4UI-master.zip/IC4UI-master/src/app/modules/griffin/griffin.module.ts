import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GriffinRoutingModule } from './griffin-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    GriffinRoutingModule
  ]
})
export class GriffinModule { }
