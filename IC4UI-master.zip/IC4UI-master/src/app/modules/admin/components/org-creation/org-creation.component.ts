import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-org-creation',
  templateUrl: './org-creation.component.html',
  styleUrls: ['./org-creation.component.scss']
})
export class OrgCreationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
