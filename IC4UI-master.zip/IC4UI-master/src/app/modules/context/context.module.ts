import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ContextRoutingModule } from './context-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ContextRoutingModule
  ]
})
export class ContextModule { }
