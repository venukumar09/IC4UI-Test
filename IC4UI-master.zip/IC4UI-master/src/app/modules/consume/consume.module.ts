import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ConsumeRoutingModule } from './consume-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ConsumeRoutingModule
  ]
})
export class ConsumeModule { }
